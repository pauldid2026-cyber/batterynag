package com.batterynag.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager

class ToneReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val battery = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (level >= 0) {
            val pct = level * 100 / scale
            if (pct <= 30) {
                BatteryNag.tone(context)
                BatteryNag.evaluate(context, pct)
            }
        }
    }
}
