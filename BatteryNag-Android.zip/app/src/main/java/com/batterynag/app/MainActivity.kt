package com.batterynag.app

import android.Manifest
import android.app.*
import android.content.*
import android.os.*
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(0xFF000000.toInt())
        }

        val title = TextView(this).apply {
            text = "BATTERY NAG"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        status = TextView(this).apply {
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 30)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        val info = TextView(this).apply {
            text = "Warns below 30% and gets more frequent as the battery falls."
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2))

        val label = TextView(this).apply {
            text = "IGNORE WARNINGS FOR:"
            textSize = 14f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 40, 0, 15)
        }
        root.addView(label)

        listOf(1,2,3,4,5).forEach { h ->
            val b = Button(this).apply {
                text = "$h HOUR${if (h > 1) "S" else ""}"
                setOnClickListener {
                    BatteryNag.snooze(this@MainActivity, h)
                    updateStatus()
                    Toast.makeText(this@MainActivity, "Warnings snoozed for $h hour(s)", Toast.LENGTH_SHORT).show()
                }
            }
            root.addView(b, LinearLayout.LayoutParams(-1, 55).apply { setMargins(0, 4, 0, 4) })
        }

        setContentView(root)
        updateStatus()
    }

    private fun updateStatus() {
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra("level", -1) ?: -1
        val scale = battery?.getIntExtra("scale", 100) ?: 100
        val pct = if (level >= 0) level * 100 / scale else -1
        status.text = if (BatteryNag.isSnoozed(this))
            "Warnings snoozed"
        else
            "Battery: $pct%"
    }
}
