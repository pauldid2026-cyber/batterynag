package com.batterynag.app

import android.app.*
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.TimeUnit

object BatteryNag {
    private const val PREFS = "battery_nag"
    private const val SNOOZE_UNTIL = "snooze_until"
    private const val CHANNEL = "battery_warning"

    fun evaluate(context: Context, percent: Int) {
        if (percent > 30 || isSnoozed(context)) {
            if (percent > 30) stop(context)
            return
        }
        notify(context, percent)
        val interval = intervalFor(percent)
        scheduleTone(context, interval)
    }

    private fun intervalFor(percent: Int): Long {
        return when {
            percent <= 5 -> 15_000L
            percent <= 10 -> 30_000L
            percent <= 15 -> 60_000L
            percent <= 20 -> 120_000L
            percent <= 25 -> 300_000L
            else -> 600_000L
        }
    }

    private fun scheduleTone(context: Context, delay: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ToneReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.cancel(pi)
        alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + delay, pi)
    }

    fun tone(context: Context) {
        if (isSnoozed(context)) return
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val intent = Intent(context, BatteryReceiver::class.java)
        context.sendBroadcast(intent)
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100).apply {
            startTone(ToneGenerator.TONE_PROP_BEEP, 350)
            Handler(Looper.getMainLooper()).postDelayed({ release() }, 500)
        }
    }

    fun snooze(context: Context, hours: Int) {
        context.getSharedPreferences(PREFS, 0).edit()
            .putLong(SNOOZE_UNTIL, System.currentTimeMillis() + TimeUnit.HOURS.toMillis(hours))
            .apply()
        stop(context)
    }

    fun isSnoozed(context: Context): Boolean =
        System.currentTimeMillis() < context.getSharedPreferences(PREFS, 0)
            .getLong(SNOOZE_UNTIL, 0L)

    fun stop(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            context, 1001, Intent(context, ToneReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.cancel(pi)
    }

    private fun notify(context: Context, percent: Int) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL, "Battery warnings", NotificationManager.IMPORTANCE_HIGH
            ))
        }
        val builder = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setContentTitle("Battery Nag")
            .setContentText("Battery is at $percent%. Plug me in.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setAutoCancel(false)
        nm.notify(42, builder.build())
    }
}
